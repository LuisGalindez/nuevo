﻿using System.Windows.Forms;

namespace Vender_Bosquejo_2
{
    partial class FormVender
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormVender));
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblPosicion = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.btnEliminar = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblRegresar = new System.Windows.Forms.Label();
            this.lblDatosCliente = new System.Windows.Forms.Label();
            this.lblDatosDelCliente = new System.Windows.Forms.Label();
            this.lblVendedor = new System.Windows.Forms.Label();
            this.lblDatosVendedor = new System.Windows.Forms.Label();
            this.btnListaProductos = new System.Windows.Forms.Button();
            this.lblCliente = new System.Windows.Forms.Label();
            this.lblPrecioBase = new System.Windows.Forms.Label();
            this.lblBase = new System.Windows.Forms.Label();
            this.lblFinal = new System.Windows.Forms.Label();
            this.btnBorrar = new System.Windows.Forms.Button();
            this.lblFechaActual = new System.Windows.Forms.Label();
            this.lblFecha = new System.Windows.Forms.Label();
            this.cbBoxClientes = new System.Windows.Forms.ComboBox();
            this.btnNuevoCliente = new System.Windows.Forms.Button();
            this.lblPrecioFinal = new System.Windows.Forms.Label();
            this.btnFacturar = new System.Windows.Forms.Button();
            this.dtgvPreview = new System.Windows.Forms.DataGridView();
            this.Codigo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nombre = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Precio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrecioTotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEliminar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPreview)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.lblPosicion);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.btnEliminar);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.lblRegresar);
            this.panel1.Controls.Add(this.lblDatosCliente);
            this.panel1.Controls.Add(this.lblDatosDelCliente);
            this.panel1.Controls.Add(this.lblVendedor);
            this.panel1.Controls.Add(this.lblDatosVendedor);
            this.panel1.Controls.Add(this.btnListaProductos);
            this.panel1.Controls.Add(this.lblCliente);
            this.panel1.Controls.Add(this.lblPrecioBase);
            this.panel1.Controls.Add(this.lblBase);
            this.panel1.Controls.Add(this.lblFinal);
            this.panel1.Controls.Add(this.btnBorrar);
            this.panel1.Controls.Add(this.lblFechaActual);
            this.panel1.Controls.Add(this.lblFecha);
            this.panel1.Controls.Add(this.cbBoxClientes);
            this.panel1.Controls.Add(this.btnNuevoCliente);
            this.panel1.Controls.Add(this.lblPrecioFinal);
            this.panel1.Controls.Add(this.btnFacturar);
            this.panel1.Controls.Add(this.dtgvPreview);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1131, 625);
            this.panel1.TabIndex = 0;
            // 
            // lblPosicion
            // 
            this.lblPosicion.AutoSize = true;
            this.lblPosicion.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblPosicion.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPosicion.Location = new System.Drawing.Point(160, 576);
            this.lblPosicion.Name = "lblPosicion";
            this.lblPosicion.Padding = new System.Windows.Forms.Padding(4);
            this.lblPosicion.Size = new System.Drawing.Size(160, 31);
            this.lblPosicion.TabIndex = 76;
            this.lblPosicion.Text = "Posicion del index";
            this.lblPosicion.Visible = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox2.Image = global::ExamenDockUp.Properties.Resources.Factura;
            this.pictureBox2.Location = new System.Drawing.Point(1078, 324);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(44, 44);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 75;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.btnFacturar_Click_1);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnEliminar.Image = global::ExamenDockUp.Properties.Resources.botonX;
            this.btnEliminar.Location = new System.Drawing.Point(1076, 154);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(44, 44);
            this.btnEliminar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.btnEliminar.TabIndex = 74;
            this.btnEliminar.TabStop = false;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBox1.Image = global::ExamenDockUp.Properties.Resources.Regresar1;
            this.pictureBox1.Location = new System.Drawing.Point(11, 572);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(42, 42);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 73;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.lblRegresar_Click);
            // 
            // lblRegresar
            // 
            this.lblRegresar.AutoSize = true;
            this.lblRegresar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.lblRegresar.Font = new System.Drawing.Font("Microsoft PhagsPa", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegresar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.lblRegresar.Location = new System.Drawing.Point(54, 582);
            this.lblRegresar.Name = "lblRegresar";
            this.lblRegresar.Size = new System.Drawing.Size(76, 21);
            this.lblRegresar.TabIndex = 72;
            this.lblRegresar.Text = "Regresar";
            this.lblRegresar.Click += new System.EventHandler(this.lblRegresar_Click);
            // 
            // lblDatosCliente
            // 
            this.lblDatosCliente.AutoSize = true;
            this.lblDatosCliente.Location = new System.Drawing.Point(544, 65);
            this.lblDatosCliente.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDatosCliente.Name = "lblDatosCliente";
            this.lblDatosCliente.Size = new System.Drawing.Size(88, 20);
            this.lblDatosCliente.TabIndex = 71;
            this.lblDatosCliente.Text = "Sin Asignar";
            // 
            // lblDatosDelCliente
            // 
            this.lblDatosDelCliente.AutoSize = true;
            this.lblDatosDelCliente.Location = new System.Drawing.Point(531, 39);
            this.lblDatosDelCliente.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDatosDelCliente.Name = "lblDatosDelCliente";
            this.lblDatosDelCliente.Size = new System.Drawing.Size(131, 20);
            this.lblDatosDelCliente.TabIndex = 70;
            this.lblDatosDelCliente.Text = "Datos del Cliente:";
            // 
            // lblVendedor
            // 
            this.lblVendedor.AutoSize = true;
            this.lblVendedor.Location = new System.Drawing.Point(290, 65);
            this.lblVendedor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblVendedor.Name = "lblVendedor";
            this.lblVendedor.Size = new System.Drawing.Size(94, 20);
            this.lblVendedor.TabIndex = 69;
            this.lblVendedor.Text = "lblVendedor";
            // 
            // lblDatosVendedor
            // 
            this.lblDatosVendedor.AutoSize = true;
            this.lblDatosVendedor.Location = new System.Drawing.Point(290, 39);
            this.lblDatosVendedor.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDatosVendedor.Name = "lblDatosVendedor";
            this.lblDatosVendedor.Size = new System.Drawing.Size(151, 20);
            this.lblDatosVendedor.TabIndex = 68;
            this.lblDatosVendedor.Text = "Datos del Vendedor:";
            // 
            // btnListaProductos
            // 
            this.btnListaProductos.BackColor = System.Drawing.SystemColors.ControlDark;
            this.btnListaProductos.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnListaProductos.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnListaProductos.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListaProductos.ForeColor = System.Drawing.Color.White;
            this.btnListaProductos.Location = new System.Drawing.Point(757, 65);
            this.btnListaProductos.Margin = new System.Windows.Forms.Padding(6, 2, 6, 2);
            this.btnListaProductos.Name = "btnListaProductos";
            this.btnListaProductos.Size = new System.Drawing.Size(246, 41);
            this.btnListaProductos.TabIndex = 57;
            this.btnListaProductos.Text = "Lista de Productos";
            this.btnListaProductos.UseVisualStyleBackColor = false;
            this.btnListaProductos.Click += new System.EventHandler(this.btnListaProductos_Click);
            // 
            // lblCliente
            // 
            this.lblCliente.AutoSize = true;
            this.lblCliente.Location = new System.Drawing.Point(5, 3);
            this.lblCliente.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblCliente.Name = "lblCliente";
            this.lblCliente.Size = new System.Drawing.Size(61, 20);
            this.lblCliente.TabIndex = 67;
            this.lblCliente.Text = "Cliente:";
            // 
            // lblPrecioBase
            // 
            this.lblPrecioBase.AutoSize = true;
            this.lblPrecioBase.Location = new System.Drawing.Point(542, 578);
            this.lblPrecioBase.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPrecioBase.Name = "lblPrecioBase";
            this.lblPrecioBase.Size = new System.Drawing.Size(93, 20);
            this.lblPrecioBase.TabIndex = 66;
            this.lblPrecioBase.Text = "Precio Base:";
            // 
            // lblBase
            // 
            this.lblBase.AutoSize = true;
            this.lblBase.Location = new System.Drawing.Point(684, 579);
            this.lblBase.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblBase.Name = "lblBase";
            this.lblBase.Size = new System.Drawing.Size(59, 20);
            this.lblBase.TabIndex = 65;
            this.lblBase.Text = "lblBase";
            // 
            // lblFinal
            // 
            this.lblFinal.AutoSize = true;
            this.lblFinal.Location = new System.Drawing.Point(776, 578);
            this.lblFinal.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblFinal.Name = "lblFinal";
            this.lblFinal.Size = new System.Drawing.Size(93, 20);
            this.lblFinal.TabIndex = 64;
            this.lblFinal.Text = "Precio Final:";
            // 
            // btnBorrar
            // 
            this.btnBorrar.BackColor = System.Drawing.Color.Crimson;
            this.btnBorrar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBorrar.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnBorrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBorrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBorrar.ForeColor = System.Drawing.Color.White;
            this.btnBorrar.Location = new System.Drawing.Point(922, 161);
            this.btnBorrar.Margin = new System.Windows.Forms.Padding(6, 2, 6, 2);
            this.btnBorrar.Name = "btnBorrar";
            this.btnBorrar.Size = new System.Drawing.Size(147, 33);
            this.btnBorrar.TabIndex = 59;
            this.btnBorrar.Text = "Eliminar";
            this.btnBorrar.UseVisualStyleBackColor = false;
            this.btnBorrar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // lblFechaActual
            // 
            this.lblFechaActual.AutoSize = true;
            this.lblFechaActual.Location = new System.Drawing.Point(850, 16);
            this.lblFechaActual.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblFechaActual.Name = "lblFechaActual";
            this.lblFechaActual.Size = new System.Drawing.Size(111, 20);
            this.lblFechaActual.TabIndex = 63;
            this.lblFechaActual.Text = "lblFechaActual";
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Location = new System.Drawing.Point(774, 16);
            this.lblFecha.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(53, 20);
            this.lblFecha.TabIndex = 62;
            this.lblFecha.Text = "Fecha:";
            // 
            // cbBoxClientes
            // 
            this.cbBoxClientes.FormattingEnabled = true;
            this.cbBoxClientes.Location = new System.Drawing.Point(11, 39);
            this.cbBoxClientes.Margin = new System.Windows.Forms.Padding(6, 2, 6, 2);
            this.cbBoxClientes.Name = "cbBoxClientes";
            this.cbBoxClientes.Size = new System.Drawing.Size(223, 26);
            this.cbBoxClientes.TabIndex = 55;
            this.cbBoxClientes.Text = "Seleccionar";
            this.cbBoxClientes.SelectedIndexChanged += new System.EventHandler(this.cbBoxClientes_SelectedIndexChanged);
            // 
            // btnNuevoCliente
            // 
            this.btnNuevoCliente.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnNuevoCliente.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.btnNuevoCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnNuevoCliente.Font = new System.Drawing.Font("Franklin Gothic Medium", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnNuevoCliente.ForeColor = System.Drawing.Color.White;
            this.btnNuevoCliente.Location = new System.Drawing.Point(11, 94);
            this.btnNuevoCliente.Margin = new System.Windows.Forms.Padding(6, 2, 6, 2);
            this.btnNuevoCliente.Name = "btnNuevoCliente";
            this.btnNuevoCliente.Size = new System.Drawing.Size(197, 44);
            this.btnNuevoCliente.TabIndex = 56;
            this.btnNuevoCliente.Text = "Crear Nuevo Cliente";
            this.btnNuevoCliente.UseVisualStyleBackColor = false;
            this.btnNuevoCliente.Click += new System.EventHandler(this.btnNuevoCliente_Click);
            // 
            // lblPrecioFinal
            // 
            this.lblPrecioFinal.AutoSize = true;
            this.lblPrecioFinal.Location = new System.Drawing.Point(914, 578);
            this.lblPrecioFinal.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblPrecioFinal.Name = "lblPrecioFinal";
            this.lblPrecioFinal.Size = new System.Drawing.Size(59, 20);
            this.lblPrecioFinal.TabIndex = 60;
            this.lblPrecioFinal.Text = "lblFinal";
            // 
            // btnFacturar
            // 
            this.btnFacturar.BackColor = System.Drawing.Color.YellowGreen;
            this.btnFacturar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnFacturar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnFacturar.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFacturar.ForeColor = System.Drawing.Color.White;
            this.btnFacturar.Location = new System.Drawing.Point(926, 336);
            this.btnFacturar.Margin = new System.Windows.Forms.Padding(6, 2, 6, 2);
            this.btnFacturar.Name = "btnFacturar";
            this.btnFacturar.Size = new System.Drawing.Size(147, 33);
            this.btnFacturar.TabIndex = 61;
            this.btnFacturar.Text = "Facturar";
            this.btnFacturar.UseVisualStyleBackColor = false;
            this.btnFacturar.Click += new System.EventHandler(this.btnFacturar_Click_1);
            // 
            // dtgvPreview
            // 
            this.dtgvPreview.AllowUserToAddRows = false;
            this.dtgvPreview.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtgvPreview.BackgroundColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dtgvPreview.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dtgvPreview.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.Sunken;
            this.dtgvPreview.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            this.dtgvPreview.ColumnHeadersHeight = 36;
            this.dtgvPreview.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dtgvPreview.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Codigo,
            this.Nombre,
            this.Descripcion,
            this.Precio,
            this.Cantidad,
            this.PrecioTotal});
            this.dtgvPreview.GridColor = System.Drawing.SystemColors.AppWorkspace;
            this.dtgvPreview.Location = new System.Drawing.Point(9, 155);
            this.dtgvPreview.Margin = new System.Windows.Forms.Padding(4);
            this.dtgvPreview.MultiSelect = false;
            this.dtgvPreview.Name = "dtgvPreview";
            this.dtgvPreview.ReadOnly = true;
            this.dtgvPreview.RowHeadersVisible = false;
            this.dtgvPreview.RowHeadersWidth = 20;
            this.dtgvPreview.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dtgvPreview.RowTemplate.Height = 29;
            this.dtgvPreview.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.dtgvPreview.Size = new System.Drawing.Size(904, 410);
            this.dtgvPreview.TabIndex = 58;
            this.dtgvPreview.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtgvPreview_CellContentClick);
            // 
            // Codigo
            // 
            this.Codigo.HeaderText = "Codigo";
            this.Codigo.MinimumWidth = 6;
            this.Codigo.Name = "Codigo";
            this.Codigo.ReadOnly = true;
            // 
            // Nombre
            // 
            this.Nombre.HeaderText = "Nombre";
            this.Nombre.MinimumWidth = 6;
            this.Nombre.Name = "Nombre";
            this.Nombre.ReadOnly = true;
            // 
            // Descripcion
            // 
            this.Descripcion.HeaderText = "Descripcion";
            this.Descripcion.MinimumWidth = 6;
            this.Descripcion.Name = "Descripcion";
            this.Descripcion.ReadOnly = true;
            // 
            // Precio
            // 
            this.Precio.HeaderText = "Precio";
            this.Precio.MinimumWidth = 6;
            this.Precio.Name = "Precio";
            this.Precio.ReadOnly = true;
            // 
            // Cantidad
            // 
            this.Cantidad.HeaderText = "Cantidad";
            this.Cantidad.MinimumWidth = 6;
            this.Cantidad.Name = "Cantidad";
            this.Cantidad.ReadOnly = true;
            // 
            // PrecioTotal
            // 
            this.PrecioTotal.HeaderText = "Precio Total";
            this.PrecioTotal.MinimumWidth = 8;
            this.PrecioTotal.Name = "PrecioTotal";
            this.PrecioTotal.ReadOnly = true;
            // 
            // FormVender
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1154, 649);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft PhagsPa", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.WindowText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(6, 2, 6, 2);
            this.Name = "FormVender";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Vender";
            this.Load += new System.EventHandler(this.FormVenderV2_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnEliminar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dtgvPreview)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox2;
        private PictureBox btnEliminar;
        private PictureBox pictureBox1;
        private Label lblRegresar;
        private Label lblDatosCliente;
        private Label lblDatosDelCliente;
        private Label lblVendedor;
        private Label lblDatosVendedor;
        private Button btnListaProductos;
        private Label lblCliente;
        private Label lblPrecioBase;
        private Label lblBase;
        private Label lblFinal;
        private Button btnBorrar;
        private Label lblFechaActual;
        private Label lblFecha;
        private ComboBox cbBoxClientes;
        private Button btnNuevoCliente;
        private Label lblPrecioFinal;
        private Button btnFacturar;
        private DataGridView dtgvPreview;
        private DataGridViewTextBoxColumn Codigo;
        private DataGridViewTextBoxColumn Nombre;
        private DataGridViewTextBoxColumn Descripcion;
        private DataGridViewTextBoxColumn Precio;
        private DataGridViewTextBoxColumn Cantidad;
        private Label lblPosicion;
        private DataGridViewTextBoxColumn PrecioTotal;
    }
}