﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using borrador;
using DatosEmpresa;
using Newtonsoft.Json;
using System.Collections;
using System.IO;
using ExamenDockUp;

namespace Vender_Bosquejo_2
{
    public partial class FormAgregarProducto : Form
    {
        private int n = -1;
        private int _cantidadSeleccionada = 0;
        private double _precioBase = 0;
        private double _precioFinal = 0;
        private List<Productos> _compras = new List<Productos>(); //Carrito del Comprador
        private List<Productos> _productos = new List<Productos>(); //Productos Disponibles
        private DataGridView CopiaPreview = new DataGridView();
        private Label lblBase = new Label();
        private Label lblFinal = new Label();
        public double PrecioBase { get { return _precioBase; } set { _precioBase = value; } }
        public double PrecioFinal { get { return _precioFinal; } set { _precioFinal = value; } }
        public int CantidadSeleccionada { get { return _cantidadSeleccionada; } set { _cantidadSeleccionada=value; } }
        public List<Productos> Productos { get { return _productos; } set { _productos = value; } }
        public List<Productos> ComprasCliente { get { return _compras; } set { _compras = value; } }
        public DataGridView DataGrid { get { return CopiaPreview; } set { CopiaPreview = value; } }
        public Label lblPrecioBase { get { return lblBase; } set { lblBase = value; } }
        public Label lblPrecioFinal { get { return lblFinal; } set { lblFinal = value; } }
        public FormAgregarProducto()
        {
            InitializeComponent();
            Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - Width, 0);
        }
        private void btnRegresar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void SumarFila()
        {
            _precioBase = 0;
            foreach (DataGridViewRow row in CopiaPreview.Rows)
            {
                _precioBase += Convert.ToDouble(row.Cells["PrecioTotal"].Value);
            }
            lblBase.Text = Convert.ToString(_precioBase);
        }
        private void CalcularIva()
        {            
            double Porcentaje = 0;
            Porcentaje = (_precioBase * 16) / 100;
            _precioFinal = Porcentaje + _precioBase;
            lblPrecioFinal.Text = Convert.ToString(_precioFinal);            
        }
        private void FormAgregarProducto_Load(object sender, EventArgs e)
        {
            n = -1;
            lblPosicion.Visible = false;

            dtgvListaDeProductos.Rows.Clear();
            if (Productos.Count != 0)
            {
                dtgvListaDeProductos.Rows.Add(Productos.Count);

                for (int i = 0; i < Productos.Count; i++)
                {
                    for (int j = 0; j < dtgvListaDeProductos.Columns.Count; j++)
                    {
                        if (j == 0) dtgvListaDeProductos[j, i].Value = _productos[i]._codigo;
                        else if (j == 1) dtgvListaDeProductos[j, i].Value = _productos[i]._nombre;
                        else if (j == 2) dtgvListaDeProductos[j, i].Value = _productos[i]._descripcion;
                        else if (j == 3) dtgvListaDeProductos[j, i].Value = _productos[i]._precio;
                        else if (j == 4) dtgvListaDeProductos[j, i].Value = _productos[i]._cantidad;
                    }
                }  
            }
            else MessageBox.Show("No existe Producto alguno para mostrar", "Inexistencia de Productos", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if(n != -1)
            {
                try
                {
                    if (string.IsNullOrEmpty(txtCantidad.Text)) { throw new Exception("El campo de cantidad no puede quedar vacio"); }
                    if (!int.TryParse(txtCantidad.Text, out _cantidadSeleccionada))
                    {
                        throw new Exception("El formato de la Cantidad es Incorrecto.\nNo se permite el uso de Caracteres");
                    }
                    if (_cantidadSeleccionada <= 0) { throw new Exception("No puede aniadir una cantidad que no existe"); }

                    _compras.Add(_productos[n]);
                    _compras[_compras.Count - 1]._cantidad = CantidadSeleccionada;
                    int aux = CopiaPreview.Rows.Add();
                    CopiaPreview[0, aux].Value = _productos[n]._codigo;
                    CopiaPreview[1, aux].Value = _productos[n]._nombre;
                    CopiaPreview[2, aux].Value = _productos[n]._descripcion;
                    CopiaPreview[3, aux].Value = _productos[n]._precio;
                    CopiaPreview[4, aux].Value = _cantidadSeleccionada;
                    CopiaPreview[5, aux].Value = _cantidadSeleccionada * _productos[n]._precio;
                    SumarFila();
                    CalcularIva();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else MessageBox.Show("No ha Seleccionado Producto Alguno a Agregar","Por Favor Seleccione Algun Producto",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
        }

        private void dtgvListaDeProductos_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            n = e.RowIndex;
            lblPosicion.Visible = true;
            lblPosicion.Text = $"Numero de Fila del Producto Seleccionado: {e.RowIndex + 1}";
        }
    }
}
