using borrador;
using DatosEmpresa;
using ExamenDockUp;
using Microsoft.Vbe.Interop;
using Newtonsoft.Json;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vender_Bosquejo_2
{
    public partial class FormVender : Form
    {
        private int n = -1;
        private double _precioBase = 0;
        private double _precioFinal = 0;
        private int _cantidadSeleccionada = 0;
        private List<Cliente> _clientes = new List<Cliente>();
        private List<Productos> _compras = new List<Productos>(); //Carrito del Comprador
        private List<Productos> _productosDisponibles = new List<Productos>(); //Productos disponibles
        private List<Productos> _productosListaOriginal = new List<Productos>(); //Todos los productos, contando hasta los ya "Eliminados"
        private List<string> _datosEmpresa = new List<string>();
        private Usuario _vendedor = new Usuario();
        private FormFactura Factura = new FormFactura();
        private FormAgregarProducto ListaDeProductos = new FormAgregarProducto();
        private FormAgregarCliente AgregarCliente = new FormAgregarCliente();
        private string _pathFacturas = "";
        private string _pathClientes = "";
        public FormVender()
        {
            InitializeComponent();
            Location = new Point(0, Screen.PrimaryScreen.WorkingArea.Height - Height);
        }
        public List<string> DatosEmpresa { get { return _datosEmpresa; } set { _datosEmpresa = value; } }
        public List<Productos> Productos { get { return _productosListaOriginal; } set { _productosListaOriginal = value; } }
        public List<Cliente> Clientes { get { return _clientes; } set { _clientes = value; } }
        public Usuario Vendedor { get { return _vendedor; } set { _vendedor = value; } }
        public string PathClientes { get { return _pathClientes; } set { _pathClientes = value; } }
        public string PathFacturas { get { return _pathFacturas; } set { _pathFacturas = value; } }
        private void ConectarInformacion()
        {
            ListaDeProductos.Productos = ListaProductosDisponibles();
            ListaDeProductos.ComprasCliente = _compras;
            ListaDeProductos.CantidadSeleccionada = _cantidadSeleccionada;
            ListaDeProductos.DataGrid = dtgvPreview;
            ListaDeProductos.PrecioBase = _precioBase;
            ListaDeProductos.PrecioFinal = _precioFinal;
            ListaDeProductos.lblPrecioBase = lblBase;
            ListaDeProductos.lblPrecioFinal = lblPrecioFinal;

            Factura.Vendedor = _vendedor;
            Factura.Compras = _compras;
            Factura.Path = _pathFacturas;
            Factura.DatosEmpresa = _datosEmpresa;
            Factura.CBClientes = cbBoxClientes;
            Factura.DataPreview = dtgvPreview;

            AgregarCliente.ListaClientes = _clientes;
            AgregarCliente.PathClientes = _pathClientes;
        }
        private List<Productos> ListaProductosDisponibles()
        {
            _productosDisponibles.Clear();

            for (int i = 0; i < _productosListaOriginal.Count; i++)
            {
                if (_productosListaOriginal[i]._disponible == true)
                {
                    _productosDisponibles.Add(_productosListaOriginal[i]);
                    //_productosDisponibles.Add(new Productos(productos[i]._codigo, productos[i]._nombre, productos[i]._descripcion, productos[i]._cantidad, productos[i]._precio));
                }
            }

            return _productosDisponibles;
        }
        private void ReiniciarDatosCliente()
        {
            LlenarComboBoxClientes();
            cbBoxClientes.SelectedIndex = -1;
            cbBoxClientes.Text = "Seleccionar";
            lblDatosCliente.Text = "No Seleccionado";
        }
        private void ReiniciarPrecios()
        {
            _precioBase = 0;
            _precioFinal = 0;
            lblBase.Text = _precioBase.ToString();
            lblPrecioFinal.Text = _precioFinal.ToString();
        }
        private void LlenarComboBoxClientes()
        {
            cbBoxClientes.Items.Clear();
            for(int i=0; i<_clientes.Count; i++)
            {
                cbBoxClientes.Items.Add(_clientes[i].Identificacion());
            }
        }
        private void btnListaProductos_Click(object sender, EventArgs e)
        { 
            ListaDeProductos.ShowDialog();
            //SumarColumnas();
            SumarFila();
            CalcularIva();
        }       
        private void btnNuevoCliente_Click(object sender, EventArgs e)
        {
            int RespaldoCantidadDeClientes = _clientes.Count;
            AgregarCliente.ShowDialog();

            if(RespaldoCantidadDeClientes != _clientes.Count)
            {
                LlenarComboBoxClientes();
                cbBoxClientes.SelectedIndex = _clientes.Count - 1;
                lblDatosCliente.Text = _clientes[cbBoxClientes.SelectedIndex].Identificacion();
            }
        }
        private void FormVenderV2_Load(object sender, EventArgs e)
        {
            ConectarInformacion();
            n = -1;

            lblVendedor.Text = $"{_vendedor.Nombre} {_vendedor.Apellido}";
            lblFechaActual.Text = $"{ DateTime.Now.Day}/{ DateTime.Now.Month}/{ DateTime.Now.Year}";            
            lblBase.Text = _precioBase.ToString();
            lblPrecioFinal.Text = _precioFinal.ToString();
            lblPosicion.Visible = false;

            _compras.Clear();
            dtgvPreview.Rows.Clear();

            ReiniciarDatosCliente();
            ReiniciarPrecios();
        }
        private void SumarFila()
        {
            _precioBase = 0;
            foreach (DataGridViewRow row in dtgvPreview.Rows)
            {
                _precioBase += Convert.ToDouble(row.Cells["PrecioTotal"].Value);                
            }
            lblBase.Text = Convert.ToString(_precioBase);
        }

       /* private void SumarColumnas()
        {           
                foreach (DataGridViewRow row in dtgvPreview.Rows)
                {
                    row.Cells["PrecioTotal"].Value = Convert.ToDouble(row.Cells["Precio"].Value) * Convert.ToDouble(row.Cells["Cantidad"].Value);
                //MessageBox.Show($"{row.Cells["PrecioTotal"].Value}");
                }                           
        }*/
        private void CalcularIva()
        {           
            double Porcentaje = 0;
            Porcentaje = (_precioBase * 16)/100;
            _precioFinal = Porcentaje + _precioBase;
            lblPrecioFinal.Text = Convert.ToString(_precioFinal);                        
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            try
            {
                if (n != -1 && dtgvPreview.Rows.Count > 0)
                {
                    dtgvPreview.Rows.RemoveAt(n);
                    _compras.RemoveAt(n);
                    SumarFila();
                    CalcularIva();
                    if (n > -1)
                    {
                        n--;
                        lblPosicion.Text = $"Numero de Fila del Producto Seleccionado: {n + 1}";
                    }
                    if (n + 1 == 0) lblPosicion.Visible = false;
                }
                else if (n == -1)
                {
                    throw new Exception("No se ha Seleccionado Ningun Producto a Eliminar");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message,"Error",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }

            //Borrar el precio del producto al borrar el producto
            /*foreach (DataGridViewRow row in dtgvPreview.Rows)
            {
                PrecioBase -= Convert.ToDouble(row.Cells["PrecioTotal"].Value);
            }*/
            //lblBase.Text = Convert.ToString(_precioBase);

            /*foreach (DataGridViewRow row in dtgvPreview.Rows)
            {
                PrecioFinal -= Convert.ToDouble(row.Cells["PrecioTotal"].Value);
            }*/
            //lblPrecioFinal.Text = Convert.ToString(_precioFinal);
        }
        private void dtgvPreview_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            n = e.RowIndex;
            lblPosicion.Visible = true;
            lblPosicion.Text = $"Numero de Fila del Producto Seleccionado: {e.RowIndex + 1}";
        }
        private void btnFacturar_Click_1(object sender, EventArgs e)
        {
            if (_compras.Count > 0)
            {
                if (_datosEmpresa.Count != 0)
                {
                    if(cbBoxClientes.SelectedIndex != -1)
                    {
                        Factura.SubTotal = _precioBase;
                        Factura.Total = _precioFinal;
                        Factura.Cliente = _clientes[cbBoxClientes.SelectedIndex];
                        Factura.ShowDialog();
                    }
                    else MessageBox.Show("No se ha Seleccionado al Cliente a Facturar", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else MessageBox.Show("No se han definido los Datos de la Empresa", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else MessageBox.Show("No se ha Seleccionado producto Alguno a Vender", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void cbBoxClientes_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(cbBoxClientes.SelectedIndex != -1)
            {
                lblDatosCliente.Text = _clientes[cbBoxClientes.SelectedIndex].Identificacion();
            }
            else
            {
                lblDatosCliente.Text = "No Seleccionado";
            }
        }

        private void lblRegresar_Click(object sender, EventArgs e)
        {
            this.Close();            
        }
      
    }
}